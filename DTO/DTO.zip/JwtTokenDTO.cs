﻿namespace UsersStudentsAPIApp.DTO
{
    public class JwtTokenDTO
    {
        public string? Token { get; set; }
    }
}
